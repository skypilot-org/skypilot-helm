{{- define "skypilot.checkResources" -}}
{{- $cpu := .Values.apiService.resources.requests.cpu | default "0" -}}
{{- $memory := .Values.apiService.resources.requests.memory | default "0" -}}

{{- /* Convert CPU to numeric value */ -}}
{{- $cpuNum := 0.0 -}}
{{- if kindIs "string" $cpu -}}
  {{- if hasSuffix "m" $cpu -}}
    {{- $cpuNum = float64 (divf (trimSuffix "m" $cpu | atoi) 1000) -}}
  {{- else -}}
    {{- $cpuNum = float64 ($cpu | atoi) -}}
  {{- end -}}
{{- else -}}
  {{- $cpuNum = float64 $cpu -}}
{{- end -}}

{{- /* Convert memory to Gi */ -}}
{{- $memNum := 0.0 -}}
{{- if hasSuffix "Gi" $memory -}}
  {{- $memNum = float64 (trimSuffix "Gi" $memory | atoi) -}}
{{- else if hasSuffix "Mi" $memory -}}
  {{- $memNum = float64 (divf (trimSuffix "Mi" $memory | atoi) 1024) -}}
{{- else if hasSuffix "G" $memory -}}
  {{- $memNum = float64 ($memory | trimSuffix "G" | atoi) -}}
{{- else if hasSuffix "M" $memory -}}
  {{- $memNum = float64 (divf (trimSuffix "M" $memory | atoi) 1024) -}}
{{- end -}}

{{- if or (lt $cpuNum 4.0) (lt $memNum 8.0) -}}
{{/* TODO(aylei): add a reference to the tuning guide once complete */}}
  {{- fail "Error\nDeploying a SkyPilot API server requires at least 4 CPU cores and 8 GiB memory. You can either:\n1. Change `--set apiService.resources.requests.cpu` and `--set apiService.resources.requests.memory` to meet the requirements or unset them to use defaults\n2. add `--set apiService.skipResourceCheck=true` in command args to bypass this check (not recommended for production)\nto resolve this issue and then try again." -}}
{{- end -}}

{{- end -}}

{{/*
Resolve the image name, overriding the registry when global.imageRegistry is set.
Usage: {{ include "common.image" (dict "root" . "image" "repo/name:tag") }}
*/}}
{{- define "common.image" -}}
{{- $image := default "" .image -}}
{{- $registry := default "" .root.Values.global.imageRegistry -}}
{{- if $registry -}}
  {{- $imagePath := trimPrefix "/" $image -}}
  {{- $parts := splitList "/" $imagePath -}}
  {{- if gt (len $parts) 1 -}}
    {{- $first := index $parts 0 -}}
    {{- if or (contains "." $first) (contains ":" $first) (eq $first "localhost") -}}
      {{- $imagePath = join "/" (slice $parts 1) -}}
    {{- end -}}
  {{- end -}}
  {{- printf "%s/%s" (trimSuffix "/" $registry) $imagePath -}}
{{- else -}}
  {{- $image -}}
{{- end -}}
{{- end -}}

{{/*
Pod scheduling aligned with apiService (nodeSelector, affinity, tolerations).
Applied to oauth2-proxy and bundled redis so they schedule like the API server
when umbrella charts set apiService.nodeSelector / tolerations / affinity.
*/}}
{{- define "skypilot.apiPodScheduling" -}}
{{- with .Values.apiService.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
{{- end }}
{{- with .Values.apiService.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
{{- end }}
{{- with .Values.apiService.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
{{- end }}
{{- end -}}


{{/*
Check for apiService.config during upgrade and display warning
*/}}
{{- define "skypilot.checkUpgradeConfig" -}}
{{- if and .Release.IsUpgrade .Values.apiService.config -}}
WARNING: apiService.config is set during an upgrade operation, which will be IGNORED.

To update your SkyPilot config, follow the instructions in the upgrade guide:
https://docs.skypilot.co/en/latest/reference/api-server/api-server-admin-deploy.html#setting-the-skypilot-config
{{- end -}}
{{- end -}}

{{/*
Compute full release name with optional fullnameOverride.
*/}}
{{- define "skypilot.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "skypilot.serviceAccountName" -}}
{{- if .Values.rbac.serviceAccountName -}}
{{ .Values.rbac.serviceAccountName }}
{{- else -}}
{{ include "skypilot.fullname" . }}-api-sa
{{- end -}}
{{- end -}}

{{/*
Create the namespace if not exist
*/}}
{{- define "skypilot.ensureNamespace" -}}
{{ if not (lookup "v1" "Namespace" "" .) }}
apiVersion: v1
kind: Namespace
metadata:
  name: {{ . }}
  annotations:
    {{/* Keep the namespace when uninstalling the chart, so that the deployed sky resources (if any) can still work even if the API server get uninstalled */ -}}
    helm.sh/resource-policy: keep
{{ end -}}
{{- end -}}

{{/* Whether to enable basic auth */}}
{{- define "skypilot.enableBasicAuthInAPIServer" -}}
{{- if and (not (index .Values.ingress "oauth2-proxy" "enabled")) .Values.apiService.enableUserManagement -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/* Get initial basic auth secret name */}}
{{- define "skypilot.initialBasicAuthSecretName" -}}
{{- if .Values.apiService.initialBasicAuthSecret -}}
{{ .Values.apiService.initialBasicAuthSecret }}
{{- else if .Values.apiService.initialBasicAuthCredentials -}}
{{ printf "%s-initial-basic-auth" (include "skypilot.fullname" .) }}
{{- else -}}
{{- /* Return empty string */ -}}
{{ "" }}
{{- end -}}
{{- end -}}

{{/* API server start arguments */}}
{{- define "skypilot.apiArgs" -}}
--deploy{{ if include "skypilot.enableBasicAuthInAPIServer" . | trim | eq "true" }} --enable-basic-auth{{ end }}{{ if .Values.apiService.host }} --host={{ .Values.apiService.host }}{{ end }}
{{- end -}}

{{- define "skypilot.oauth2ProxyURL" -}}
http://{{ include "skypilot.fullname" . }}-oauth2-proxy:4180
{{- end -}}

{{/* oauth2-proxy HTTP bind address; mirrors apiService.host address family so an
     IPv6 (e.g. "::") deployment binds a wildcard the pod's IPv6 network can reach. */}}
{{- define "skypilot.oauth2HttpAddress" -}}
{{- if and .Values.apiService.host (contains ":" .Values.apiService.host) -}}
[::]:4180
{{- else -}}
0.0.0.0:4180
{{- end -}}
{{- end -}}

{{- define "skypilot.ingressBasicAuthEnabled" -}}
{{- if and .Values.ingress.enabled (or .Values.ingress.authSecret .Values.ingress.authCredentials) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{- define "skypilot.ingressOAuthEnabled" -}}
{{- if and .Values.ingress.enabled (index .Values.ingress "oauth2-proxy" "enabled") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{- define "skypilot.serviceAccountAuthEnabled" -}}
{{- if include "skypilot.ingressBasicAuthEnabled" . | trim | eq "true" -}}
false
{{- else if and .Values.auth .Values.auth.serviceAccount (ne .Values.auth.serviceAccount.enabled nil) -}}
{{- .Values.auth.serviceAccount.enabled -}}
{{- else -}}
{{- .Values.apiService.enableServiceAccounts -}}
{{- end -}}
{{- end -}}

{{/* Validate the oauth config */}}
{{- define "skypilot.validateOAuthConfig" -}}
{{- $authOAuthEnabled := .Values.auth.oauth.enabled -}}
{{- $ingressBasicAuthEnabled := include "skypilot.ingressBasicAuthEnabled" . | trim | eq "true" -}}
{{- $ingressOAuthEnabled := include "skypilot.ingressOAuthEnabled" . | trim | eq "true" -}}

{{- if and $authOAuthEnabled $ingressBasicAuthEnabled -}}
  {{- fail "Error\nauth.oauth.enabled cannot be used together with ingress basic authentication (ingress.authSecret or ingress.authCredentials). These authentication methods are mutually exclusive. Please:\n1. Disable auth.oauth.enabled, OR\n2. Remove ingress.authSecret and ingress.authCredentials\nThen try again." -}}
{{- end -}}

{{- if and $authOAuthEnabled $ingressOAuthEnabled -}}
  {{- fail "Error\nauth.oauth.enabled cannot be used together with ingress OAuth2 proxy authentication (ingress.oauth2-proxy.enabled). These authentication methods are mutually exclusive. Please:\n1. Disable auth.oauth.enabled, OR\n2. Set ingress.oauth2-proxy.enabled to false\nThen try again." -}}
{{- end -}}
{{- end -}}

{{/* Validate the external proxy config */}}
{{- define "skypilot.validateExternalProxyConfig" -}}
{{- $externalProxyEnabled := .Values.auth.externalProxy.enabled -}}
{{- $authOAuthEnabled := .Values.auth.oauth.enabled -}}
{{- $ingressOAuthEnabled := include "skypilot.ingressOAuthEnabled" . | trim | eq "true" -}}

{{- if and $externalProxyEnabled $authOAuthEnabled -}}
  {{- fail "Error\nauth.externalProxy.enabled cannot be used together with auth.oauth.enabled. These authentication methods are mutually exclusive. Please:\n1. Disable auth.externalProxy.enabled, OR\n2. Set auth.oauth.enabled to false\nThen try again." -}}
{{- end -}}

{{- if and $externalProxyEnabled $ingressOAuthEnabled -}}
  {{- fail "Error\nauth.externalProxy.enabled cannot be used together with ingress.oauth2-proxy.enabled. These authentication methods are mutually exclusive. Please:\n1. Disable auth.externalProxy.enabled, OR\n2. Set ingress.oauth2-proxy.enabled to false\nThen try again." -}}
{{- end -}}
{{- end -}}
